/*
 * Assignment 4
 */
package shapes;



/**
 *
 * @author anonymous
 */
public class Shapes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println(Rectangle.area(2,4));
        
        System.out.println(Rectangle.perimeter(2,4));
        
        System.out.println(Triangle.area(3,4));
        
        System.out.println(Triangle.perimeter(3,4,5));
        
        System.out.println(Circle.area(5));
        
        System.out.println(Circle.circumference(5));
    }
    
}
