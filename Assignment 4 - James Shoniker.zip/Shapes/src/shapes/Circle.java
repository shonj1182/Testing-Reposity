/*
 * Assignment 4
 */
package shapes;

/**
 *
 * @author anonymous
 */
public class Circle {
    
    /**
     * This method takes the radius of a circle and returns the circle's area.
     * @param r the radius of the circle
     * @return the area of the circle with radius r
     */
    public static double area(double r) {
        return 3.1415*r*r;  
    }
 
    /**
     * This method takes the radius of a circle and returns the circle's circumference.
     * @param r the radius of the circle
     * @return the circumference of the circle with radius r
     */
    public static double circumference(double r) {
        return 3.1415*2*r;  
        
    }
    
}
